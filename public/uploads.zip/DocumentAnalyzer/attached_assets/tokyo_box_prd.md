# Documento de Requisitos do Produto (PRD): Tokyo Box

## Informação do Projeto

**Linguagem:** Português-Brasileiro (pt-br)
**Linguagem de Programação:** Lua, HTML/CSS, JavaScript
**Nome do Projeto:** tokyo_box
**Requisitos Originais:** Criar um script para servidor FiveM QBCore que funcione como o Spotify dentro do jogo, com permissão VIP, interface de iPhone, tema de galáxia, gerenciamento de playlists e integração com banco de dados MySQL.

## Definição do Produto

### Objetivos do Produto

1. Desenvolver uma aplicação de música integrada ao QBCore FiveM que permita aos usuários VIP escutar e gerenciar músicas dentro do jogo
2. Criar uma experiência de usuário premium com uma interface inspirada no Spotify com tema de galáxia
3. Implementar um sistema robusto de gerenciamento de dados para armazenar e sincronizar as playlists dos usuários

### Histórias de Usuário

1. Como jogador VIP, quero acessar o aplicativo Tokyo Box para ouvir música enquanto jogo, melhorando minha experiência imersiva no servidor
2. Como jogador VIP, quero criar e gerenciar minhas próprias playlists para ter acesso rápido às minhas músicas favoritas
3. Como jogador VIP, quero controlar a reprodução de música (play, pause, próxima, anterior) para personalizar minha experiência auditiva
4. Como administrador do servidor, quero gerenciar permissões VIP para o Tokyo Box para oferecer recursos exclusivos aos jogadores premium
5. Como administrador do servidor, quero monitorar o uso do sistema de música para garantir que ele não afete negativamente o desempenho do servidor

### Análise Competitiva

#### 1. Nass Advanced Music Player
**Prós:**
- Sincronização de áudio entre jogadores
- Sistema de playlists
- Músicas favoritas
- Interface mini player
- Suporte para links do Spotify

**Contras:**
- Script pago
- Sem tema personalizado de galáxia
- Sem integração específica com sistema VIP

#### 2. Car Music Player
**Prós:**
- Funcionalidade Play/pause
- Controle de volume
- Áudio espacial/3D
- Preço acessível ($10)

**Contras:**
- Limitado a veículos
- Sem sistema de playlists
- Sem interface estilo iPhone

#### 3. SpotifySystem
**Prós:**
- Interface dedicada para música
- Integração com banco de dados
- Otimizado para desempenho

**Contras:**
- Sem tema personalizado
- Sem interface estilo iPhone
- Menos recursos para gerenciamento de playlists

#### 4. xSound Music System
**Prós:**
- Biblioteca de áudio robusta
- Bom desempenho
- Flexibilidade de implementação

**Contras:**
- Requer desenvolvimento personalizado
- Sem interface pronta
- Sem sistema de gerenciamento de músicas

#### 5. DJ System
**Prós:**
- Permite compartilhamento de música
- Controles avançados
- Integração com eventos

**Contras:**
- Focado em eventos e não uso pessoal
- Interface complexa
- Sem integração com sistema VIP

#### 6. Simple Music Player
**Prós:**
- Fácil implementação
- Baixo impacto no servidor
- Interface minimalista

**Contras:**
- Funcionalidades limitadas
- Sem sistema de playlists
- Sem integração com banco de dados

#### 7. Tokyo Box (Produto Alvo)
**Prós:**
- Interface estilo iPhone com tema de galáxia
- Sistema de permissão VIP integrado
- Gerenciamento completo de playlists
- Integração com banco de dados oxmysql
- Experiência personalizada em português-brasileiro

**Contras:**
- Desenvolvimento do zero (sem base estabelecida)
- Necessidade de otimização para evitar impacto no desempenho
- Complexidade na sincronização de dados

### Quadrante Competitivo

```mermaid
quadrantChart
    title "Análise de Players de Música para FiveM"
    x-axis "Menos Recursos" --> "Mais Recursos"
    y-axis "Interface Básica" --> "Interface Premium"
    quadrant-1 "Alto potencial"
    quadrant-2 "Líderes de mercado"
    quadrant-3 "Nichos específicos"
    quadrant-4 "Recursos a melhorar"
    "Simple Music Player": [0.25, 0.20]
    "Car Music Player": [0.40, 0.35]
    "xSound Music System": [0.55, 0.30]
    "SpotifySystem": [0.65, 0.50]
    "DJ System": [0.70, 0.45]
    "Nass Advanced Music Player": [0.80, 0.75]
    "Tokyo Box": [0.75, 0.85]
```

## Especificações Técnicas

### Análise de Requisitos

O Tokyo Box será um aplicativo de música para servidores FiveM com framework QBCore, integrando funcionalidades similares ao Spotify em uma interface estilo iPhone com tema visual de galáxia. O sistema utilizará o oxmysql para gerenciamento de dados das playlists e informações dos usuários.

#### Requisitos Funcionais:

1. **Sistema de Autenticação e Permissão**
   - Integração com o sistema de permissões do QBCore
   - Verificação de status VIP para acesso ao aplicativo
   - Sistema de login automático baseado no identificador do jogador

2. **Interface de Usuário**
   - Design responsivo simulando um iPhone no canto direito da tela
   - Tema visual de galáxia (tons de roxo, azul escuro e preto com elementos cósmicos)
   - Interface similar ao Spotify com adaptações para o contexto do jogo
   - Suporte completo para português-brasileiro em todos os elementos da interface

3. **Funcionalidades de Música**
   - Reprodução de músicas via URLs (YouTube, SoundCloud, etc.)
   - Controles básicos: play, pause, próxima, anterior, ajuste de volume
   - Barra de progresso da música com possibilidade de avançar/retroceder
   - Exibição de informações da música atual (título, artista, capa)

4. **Gerenciamento de Playlists**
   - Criação, edição e exclusão de playlists personalizadas
   - Adição e remoção de músicas das playlists
   - Pesquisa de músicas por título ou artista
   - Sistema de músicas favoritas

5. **Banco de Dados**
   - Utilização do oxmysql para armazenamento e gerenciamento de dados
   - Tabelas para usuários, músicas, playlists e configurações
   - Sincronização em tempo real dos dados entre cliente e servidor

6. **Otimização**
   - Sistema de caching para melhorar desempenho
   - Carregamento assíncrono de dados para não impactar o servidor
   - Limitação de recursos para garantir estabilidade do servidor

### Pool de Requisitos

#### P0 (Essencial)

1. Sistema de verificação de permissão VIP
2. Interface estilo iPhone com tema de galáxia
3. Reprodução básica de música (play, pause, próxima, anterior)
4. Armazenamento e gerenciamento de playlists via oxmysql
5. Interface em português-brasileiro
6. Exibição de informações básicas da música (título, artista)

#### P1 (Importante)

1. Sistema de busca de músicas
2. Controle de volume
3. Barra de progresso interativa
4. Sistema de músicas favoritas
5. Exibição de capas/thumbnails das músicas
6. Notificações no jogo sobre músicas em reprodução
7. Compartilhamento de músicas entre usuários VIP

#### P2 (Desejável)

1. Efeitos visuais durante a reprodução (visualizador de música)
2. Integração com eventos do servidor (playlists especiais em eventos)
3. Sistema de recomendação baseado em histórico
4. Estatísticas de uso (músicas mais ouvidas, tempo de reprodução)
5. Modo DJ para eventos especiais
6. Opção de download de playlists para uso offline

### Esboço de Design da UI

A interface do Tokyo Box será dividida em seções principais inspiradas no Spotify, mas com tema visual de galáxia:

1. **Tela Principal**
   - Frame de iPhone posicionado no canto direito da tela
   - Barra de status simulando um iPhone (hora, bateria, sinal)
   - Logo "Tokyo Box" no topo com elementos visuais de galáxia
   - Menu de navegação na parte inferior (Home, Busca, Biblioteca)

2. **Home**
   - Playlists recentes do usuário
   - Músicas recentemente reproduzidas
   - Recomendações personalizadas
   - Banner promocional para eventos do servidor

3. **Busca**
   - Campo de pesquisa
   - Resultados categorizados (músicas, playlists)
   - Histórico de pesquisas recentes

4. **Biblioteca**
   - Playlists do usuário
   - Músicas favoritas
   - Opção de criar nova playlist

5. **Player**
   - Capa/thumbnail da música atual
   - Título e artista
   - Controles de reprodução (anterior, play/pause, próxima)
   - Barra de progresso
   - Controle de volume
   - Botões de opções adicionais (favoritar, adicionar à playlist)

6. **Tela de Playlist**
   - Capa da playlist
   - Nome e descrição
   - Número de músicas e duração total
   - Lista de músicas com opções de gerenciamento

### Perguntas em Aberto

1. **Integração com QBCore:**
   - Como será feita a verificação de permissão VIP no sistema atual do servidor?
   - Existem hooks específicos do QBCore que precisam ser utilizados?

2. **Limitações de Recursos:**
   - Qual é o impacto de desempenho aceitável para o script no servidor?
   - Existem restrições quanto ao número de músicas que podem ser armazenadas por usuário?

3. **Fontes de Música:**
   - Quais plataformas serão suportadas para reprodução (YouTube, SoundCloud, links diretos, etc.)?
   - Existem restrições legais que precisam ser consideradas?

4. **Customização:**
   - O tema de galáxia será fixo ou os usuários poderão personalizar aspectos da interface?
   - Haverá opções para ajustar o tamanho/posição da interface na tela?

5. **Monetização:**
   - Além do acesso VIP, existirão outros aspectos do sistema que poderão ser monetizados?
   - Como será implementada a diferenciação entre usuários VIP e não-VIP?

## Arquitetura Técnica

### Estrutura do Banco de Dados

```sql
-- Tabela de usuários do Tokyo Box
CREATE TABLE IF NOT EXISTS `tokyo_box_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `identifier` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `last_played` varchar(255) DEFAULT NULL,
  `last_position` int(11) DEFAULT 0,
  `volume` int(11) DEFAULT 70,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de playlists
CREATE TABLE IF NOT EXISTS `tokyo_box_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  `cover_url` varchar(255) DEFAULT NULL,
  `is_favorite` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `owner_id` (`owner_id`),
  FOREIGN KEY (`owner_id`) REFERENCES `tokyo_box_users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de músicas
CREATE TABLE IF NOT EXISTS `tokyo_box_songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `artist` varchar(100) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de relacionamento entre playlists e músicas
CREATE TABLE IF NOT EXISTS `tokyo_box_playlist_songs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `playlist_id` int(11) NOT NULL,
  `song_id` int(11) NOT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `playlist_song` (`playlist_id`, `song_id`),
  KEY `song_id` (`song_id`),
  FOREIGN KEY (`playlist_id`) REFERENCES `tokyo_box_playlists` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`song_id`) REFERENCES `tokyo_box_songs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de favoritos
CREATE TABLE IF NOT EXISTS `tokyo_box_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `song_id` int(11) NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_song` (`user_id`, `song_id`),
  KEY `song_id` (`song_id`),
  FOREIGN KEY (`user_id`) REFERENCES `tokyo_box_users` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`song_id`) REFERENCES `tokyo_box_songs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### Estrutura de Arquivos

```
tokyo_box/
├── client/
│   ├── main.lua            # Ponto de entrada do lado do cliente
│   ├── nui.lua             # Gerenciamento da interface NUI
│   ├── player.lua          # Funcionalidade do player de música
│   └── permissions.lua     # Verificação de permissões VIP
├── server/
│   ├── main.lua            # Ponto de entrada do lado do servidor
│   ├── database.lua        # Funções de acesso ao banco de dados
│   ├── playlists.lua       # Gerenciamento de playlists
│   └── songs.lua           # Gerenciamento de músicas
├── ui/
│   ├── index.html          # Estrutura HTML principal
│   ├── css/
│   │   ├── style.css       # Estilos gerais
│   │   ├── phone.css       # Estilos para o frame do iPhone
│   │   └── player.css      # Estilos para o player de música
│   ├── js/
│   │   ├── app.js          # Lógica principal da aplicação
│   │   ├── player.js       # Funcionalidades do player
│   │   └── playlists.js    # Gerenciamento de playlists
│   └── img/                # Imagens e ícones
├── config.lua              # Configurações do script
├── fxmanifest.lua          # Manifesto do recurso FiveM
└── README.md               # Documentação
```

### Integração com QBCore

O Tokyo Box se integrará ao framework QBCore para verificação de permissões VIP e identificação de usuários:

```lua
-- Exemplo de código para verificação de permissão VIP
QBCore.Functions.CreateCallback('tokyo_box:checkVIP', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        -- Verifica se o jogador tem permissão VIP (ajustar conforme o servidor)
        local hasVIP = Player.PlayerData.metadata.vip or Player.Functions.HasPermission('vip')
        cb(hasVIP)
    else
        cb(false)
    end
 end)
```

### Fluxo de Interação do Usuário

1. **Acesso ao Aplicativo**:
   - Jogador usa comando ou tecla de atalho para abrir o Tokyo Box
   - Sistema verifica permissão VIP
   - Se autorizado, abre a interface do aplicativo

2. **Navegação**:
   - Usuário navega entre as seções Home, Busca e Biblioteca
   - Interface responde com animações suaves e feedback visual

3. **Reprodução de Música**:
   - Usuário seleciona uma música ou playlist
   - Sistema carrega os dados do servidor
   - Reprodução começa com controles disponíveis ao usuário

4. **Gerenciamento de Playlists**:
   - Usuário pode criar, editar ou excluir playlists
   - Alterações são sincronizadas com o banco de dados em tempo real

5. **Busca**:
   - Usuário digita termos de busca
   - Sistema retorna resultados relevantes
   - Usuário pode adicionar itens encontrados às suas playlists

### Métricas de Sucesso

1. **Engajamento**:
   - Número de usuários únicos utilizando o Tokyo Box
   - Tempo médio de uso por sessão
   - Frequência de uso por jogador

2. **Desempenho**:
   - Impacto no servidor (utilização de CPU/memória)
   - Tempo de resposta para operações de banco de dados
   - Estabilidade durante uso intenso

3. **Satisfação**:
   - Feedback dos jogadores
   - Taxa de retenção de usuários VIP
   - Número de playlists criadas por usuário

### Cronograma de Implementação

1. **Fase 1 - Estrutura Base (2 semanas)**
   - Configuração do banco de dados
   - Implementação da interface básica
   - Integração com sistema VIP do QBCore

2. **Fase 2 - Funcionalidades Essenciais (3 semanas)**
   - Sistema de reprodução de música
   - Gerenciamento básico de playlists
   - Sincronização com banco de dados

3. **Fase 3 - Refinamento (2 semanas)**
   - Melhorias visuais e tema de galáxia
   - Recursos avançados de playlists
   - Otimização de desempenho

4. **Fase 4 - Testes e Lançamento (1 semana)**
   - Testes internos
   - Correção de bugs
   - Lançamento para usuários VIP

## Conclusão

O Tokyo Box será um diferencial significativo para o servidor FiveM com QBCore, oferecendo uma experiência premium de reprodução de música para jogadores VIP. A combinação de uma interface inspirada no iPhone com tema de galáxia e funcionalidades robustas de gerenciamento de playlists criará um valor agregado substancial para o servidor.

Com foco na otimização de desempenho e na experiência do usuário em português-brasileiro, o Tokyo Box tem potencial para aumentar tanto a satisfação dos jogadores quanto a atratividade do pacote VIP do servidor.
