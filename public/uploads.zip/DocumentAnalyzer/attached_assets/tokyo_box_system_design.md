# Arquitetura do Sistema - Tokyo Box

## Abordagem de Implementação

Para desenvolver o Tokyo Box, um aplicativo similar ao Spotify para servidores FiveM utilizando o framework QBCore, adotaremos uma arquitetura cliente-servidor bem definida que aproveita os recursos existentes do QBCore e FiveM. O sistema será dividido em componentes para facilitar a manutenção e escalabilidade.

Principais desafios técnicos e suas soluções:

1. **Reprodução de música em tempo real**: Utilizaremos a API nativa do FiveM para reprodução de áudio (PlayUrl) para transmitir música a partir de URLs, permitindo streaming de áudio sem sobrecarregar o servidor.

2. **Persistência de dados**: Implementaremos um sistema de banco de dados MySQL usando a biblioteca oxmysql para armazenar informações de playlists, músicas favoritas e histórico de reprodução dos usuários.

3. **Interface responsiva**: Desenvolveremos uma interface NUI (NUI = FiveM Native UI) utilizando React.js, HTML5 e CSS3 para criar a experiência semelhante ao iPhone com tema de galáxia.

4. **Sistema de permissões VIP**: Integraremos com o sistema de permissões do QBCore para verificar se o jogador possui o privilégio VIP necessário para acessar o aplicativo Tokyo Box.

5. **Requisições para APIs de música**: Utilizaremos um proxy no lado do servidor para requisições a APIs de música externas, para evitar problemas de CORS e proteger qualquer chave de API necessária.

### Tecnologias e bibliotecas principais:

- **Framework**: QBCore (FiveM)
- **Frontend**: HTML5, CSS3, JavaScript, React.js
- **Backend**: Lua (padrão FiveM) + JavaScript (para a parte NUI)
- **Banco de dados**: MySQL com oxmysql
- **Reprodução de áudio**: API nativa xSound do FiveM
- **UI**: NUI Framework do FiveM

## Estruturas de Dados e Interfaces

A seguir, detalhamos as principais estruturas de dados e interfaces do sistema Tokyo Box.

### Diagrama de Classes:

O diagrama de classes representa a estrutura do sistema, incluindo as principais classes, métodos e relacionamentos entre elas:

```mermaid
classDiagram
    class TokyoBoxClient {
        <<Cliente>>
        -playerCache: object
        -isUIOpen: boolean
        -currentTrack: Track
        -currentPlaylist: Playlist
        -volume: number
        +init()
        +toggleUI()
        +playTrack(trackId: string)
        +pauseTrack()
        +resumeTrack()
        +nextTrack()
        +previousTrack()
        +setVolume(volume: number)
        +addToPlaylist(trackId: string, playlistId: string)
        +createPlaylist(name: string)
        +deletePlaylist(playlistId: string)
        +search(query: string)
        +checkVipPermission() boolean
    }

    class TokyoBoxServer {
        <<Servidor>>
        +init()
        +handlePlayerConnect(playerId: number)
        +getPlayerPlaylists(playerId: number)
        +createPlaylist(playerId: number, name: string)
        +deletePlaylist(playerId: number, playlistId: string)
        +addTrackToPlaylist(playerId: number, trackId: string, playlistId: string)
        +removeTrackFromPlaylist(playerId: number, trackId: string, playlistId: string)
        +searchTracks(query: string)
        +checkVipStatus(playerId: number) boolean
        +savePlayerSettings(playerId: number, settings: object)
    }

    class DatabaseManager {
        <<Banco de Dados>>
        +init()
        +getPlayerPlaylists(playerId: number)
        +createPlaylist(playerId: number, name: string)
        +deletePlaylist(playerId: number, playlistId: string)
        +addTrackToPlaylist(trackId: string, playlistId: string)
        +removeTrackFromPlaylist(trackId: string, playlistId: string)
        +getPlaylistTracks(playlistId: string)
        +savePlayerSettings(playerId: number, settings: object)
        +getPlayerSettings(playerId: number)
        +executeQuery(query: string, params: array)
    }

    class MusicAPI {
        <<API de Música>>
        +search(query: string)
        +getTrackInfo(trackId: string)
        +getStreamUrl(trackId: string)
        +getArtistInfo(artistId: string)
        +getPopularTracks(limit: number)
        +getNewReleases(limit: number)
    }

    class UIManager {
        <<Interface de Usuário>>
        +open()
        +close()
        +update(data: object)
        +showNotification(message: string, type: string)
        +setTheme(theme: string)
        +renderPlaylist(playlist: Playlist)
        +renderTrackList(tracks: array)
        +renderPlayer(track: Track)
        +renderSearchResults(results: array)
    }

    class User {
        <<Usuário>>
        -identifier: string
        -license: string
        -vip: boolean
        -settings: object
        +getIdentifier() string
        +isVip() boolean
        +getSettings() object
        +updateSettings(settings: object)
    }

    class Track {
        <<Faixa>>
        -id: string
        -title: string
        -artist: string
        -duration: number
        -albumArt: string
        -url: string
        +getId() string
        +getTitle() string
        +getArtist() string
        +getDuration() number
        +getAlbumArt() string
        +getUrl() string
    }

    class Playlist {
        <<Playlist>>
        -id: string
        -name: string
        -owner: string
        -tracks: array
        -createdAt: date
        -updatedAt: date
        +getId() string
        +getName() string
        +getOwner() string
        +getTracks() array
        +addTrack(track: Track)
        +removeTrack(trackId: string)
        +getCreationDate() date
        +getUpdateDate() date
    }

    TokyoBoxClient --> UIManager : usa
    TokyoBoxClient --> MusicAPI : usa
    TokyoBoxClient "1" *-- "1" User : possui
    TokyoBoxClient "1" *-- "0..*" Track : manipula
    TokyoBoxClient "1" *-- "0..*" Playlist : gerencia
    TokyoBoxServer --> DatabaseManager : usa
    TokyoBoxServer "1" *-- "0..*" User : gerencia
    TokyoBoxServer --> MusicAPI : usa
    Playlist "1" *-- "0..*" Track : contém
```

## Fluxo de Chamadas do Programa

O diagrama a seguir detalha o fluxo de interações entre os diferentes componentes do sistema:

```mermaid
sequenceDiagram
    participant J as Jogador
    participant TC as TokyoBoxClient
    participant UI as UIManager
    participant TS as TokyoBoxServer
    participant DB as DatabaseManager
    participant API as MusicAPI
    participant QBC as QBCore

    %% Inicialização do sistema
    J->>TC: Inicia o script
    TC->>QBC: Verifica permissão VIP
    QBC-->>TC: Retorna status VIP
    
    %% Abertura da interface
    J->>TC: Ativa comando /tokyobox
    TC->>QBC: checkVipPermission()
    QBC-->>TC: isVip = true/false
    alt isVip = true
        TC->>TS: getPlayerPlaylists(playerId)
        TS->>DB: getPlayerPlaylists(playerId)
        DB-->>TS: playlists
        TS-->>TC: playlists
        TC->>UI: open()
        TC->>UI: renderPlaylist(playlists)
        UI-->>J: Exibe interface do Tokyo Box
    else isVip = false
        TC->>UI: showNotification("Acesso negado, apenas VIP")
        UI-->>J: Mostra notificação de erro
    end
    
    %% Busca de músicas
    J->>UI: Realiza busca
    UI->>TC: search(query)
    TC->>TS: searchTracks(query)
    TS->>API: search(query)
    API-->>TS: searchResults
    TS-->>TC: searchResults
    TC->>UI: renderSearchResults(searchResults)
    UI-->>J: Exibe resultados da busca
    
    %% Reprodução de música
    J->>UI: Seleciona música
    UI->>TC: playTrack(trackId)
    TC->>TS: getTrackInfo(trackId)
    TS->>API: getTrackInfo(trackId)
    API-->>TS: trackInfo
    TS-->>TC: trackInfo
    TC->>TC: Reproduz áudio via xSound
    TC->>UI: renderPlayer(trackInfo)
    UI-->>J: Atualiza interface do player
    
    %% Criação de playlist
    J->>UI: Cria nova playlist
    UI->>TC: createPlaylist(name)
    TC->>TS: createPlaylist(playerId, name)
    TS->>DB: createPlaylist(playerId, name)
    DB-->>TS: playlistId
    TS-->>TC: playlistId
    TC->>UI: renderPlaylist(playlist)
    UI-->>J: Exibe nova playlist
    
    %% Adicionar música à playlist
    J->>UI: Adiciona música à playlist
    UI->>TC: addToPlaylist(trackId, playlistId)
    TC->>TS: addTrackToPlaylist(playerId, trackId, playlistId)
    TS->>API: getTrackInfo(trackId)
    API-->>TS: trackInfo
    TS->>DB: addTrackToPlaylist(trackId, playlistId)
    DB-->>TS: success
    TS-->>TC: success
    TC->>UI: update(playlist)
    UI-->>J: Atualiza playlist com nova música
    
    %% Encerramento da aplicação
    J->>UI: Fecha aplicativo
    UI->>TC: close()
    TC->>TS: savePlayerSettings(playerId, settings)
    TS->>DB: savePlayerSettings(playerId, settings)
    DB-->>TS: success
    TS-->>TC: success
    TC->>TC: isUIOpen = false
```

## Estrutura do Banco de Dados

A estrutura do banco de dados para o Tokyo Box será composta pelas seguintes tabelas:

### Tabelas MySQL

#### 1. `tokyo_box_users`
```sql
CREATE TABLE `tokyo_box_users` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `identifier` VARCHAR(50) NOT NULL,
  `license` VARCHAR(50) NOT NULL,
  `settings` TEXT,
  `last_login` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identifier_UNIQUE` (`identifier`)
);
```

#### 2. `tokyo_box_playlists`
```sql
CREATE TABLE `tokyo_box_playlists` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `user_identifier` VARCHAR(50) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_identifier_idx` (`user_identifier`),
  CONSTRAINT `fk_user_identifier` FOREIGN KEY (`user_identifier`) REFERENCES `tokyo_box_users` (`identifier`) ON DELETE CASCADE
);
```

#### 3. `tokyo_box_tracks`
```sql
CREATE TABLE `tokyo_box_tracks` (
  `id` VARCHAR(100) NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `artist` VARCHAR(150) NOT NULL,
  `duration` INT,
  `album_art` TEXT,
  `url` TEXT,
  `added_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);
```

#### 4. `tokyo_box_playlist_tracks`
```sql
CREATE TABLE `tokyo_box_playlist_tracks` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `playlist_id` INT NOT NULL,
  `track_id` VARCHAR(100) NOT NULL,
  `position` INT NOT NULL,
  `added_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `playlist_id_idx` (`playlist_id`),
  KEY `track_id_idx` (`track_id`),
  CONSTRAINT `fk_playlist_id` FOREIGN KEY (`playlist_id`) REFERENCES `tokyo_box_playlists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_track_id` FOREIGN KEY (`track_id`) REFERENCES `tokyo_box_tracks` (`id`) ON DELETE CASCADE
);
```

#### 5. `tokyo_box_favorites`
```sql
CREATE TABLE `tokyo_box_favorites` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `user_identifier` VARCHAR(50) NOT NULL,
  `track_id` VARCHAR(100) NOT NULL,
  `added_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_identifier_idx` (`user_identifier`),
  KEY `track_id_idx` (`track_id`),
  CONSTRAINT `fk_fav_user_identifier` FOREIGN KEY (`user_identifier`) REFERENCES `tokyo_box_users` (`identifier`) ON DELETE CASCADE,
  CONSTRAINT `fk_fav_track_id` FOREIGN KEY (`track_id`) REFERENCES `tokyo_box_tracks` (`id`) ON DELETE CASCADE
);
```

## Pontos que precisam de esclarecimento

1. **Fonte de músicas**: Não foi especificado qual API externa será utilizada para obtenção de músicas (YouTube, SoundCloud, etc.). Isso afetará a implementação da classe MusicAPI.

2. **Limites de VIP**: Seria útil saber se existem limites diferentes para usuários VIP (como número máximo de playlists ou músicas por playlist).

3. **Autenticação com APIs externas**: Precisamos definir como serão gerenciadas as chaves de API para serviços externos de música.

4. **Caching de áudio**: Definir se haverá cache local de músicas para otimizar o desempenho e reduzir requisições repetidas.

5. **Exigências específicas de UI**: Mais detalhes sobre a aparência exata da interface com tema de galáxia seriam úteis para a implementação.

6. **Funcionalidades sociais**: Esclarecer se haverá recursos sociais como compartilhamento de playlists entre jogadores.
