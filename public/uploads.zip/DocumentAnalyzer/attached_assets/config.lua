-- config.lua
Config = {}

-- Configurações gerais
Config.CommandName = "tokyobox" -- Comando para abrir o player de música
Config.ToggleKeybind = "F5" -- Tecla padrão para abrir/fechar o player

-- Configurações de permissões
Config.RequireVIP = true -- Se true, apenas VIPs podem usar o player
Config.VIPGroups = {"vip", "vip+", "admin", "superadmin"} -- Grupos que são considerados VIP
Config.VIPFlags = {"vip"} -- Flags que são consideradas VIP (se o servidor usar system de flags)

-- Configurações de interface
Config.PhonePosition = "right" -- Posição do "celular" na tela (right, left)
Config.DefaultVolume = 70 -- Volume padrão (0-100)
Config.EnableNotifications = true -- Habilitar notificações no jogo

-- Configurações de áudio
Config.DefaultDistance = 5.0 -- Distância para áudio 3D (se habilitado)
Config.Enable3DAudio = false -- Se true, outros jogadores próximos podem ouvir sua música

-- Configurações de banco de dados
Config.DatabaseTables = {
    users = "tokyo_box_users",
    playlists = "tokyo_box_playlists", 
    songs = "tokyo_box_songs",
    playlistSongs = "tokyo_box_playlist_songs",
    favorites = "tokyo_box_favorites"
}

-- URLs para APIs de música
Config.MusicAPIs = {
    youtube = "https://www.googleapis.com/youtube/v3",
    soundcloud = "https://api.soundcloud.com"
}

-- Limitações
Config.MaxPlaylists = 10 -- Número máximo de playlists por usuário
Config.MaxSongsPerPlaylist = 100 -- Número máximo de músicas por playlist
Config.MaxRecentSearches = 10 -- Número máximo de pesquisas recentes salvas

-- Textos de interface (pt-BR)
Config.Texts = {
    welcome = "Bem-vindo ao Tokyo Box",
    noAccess = "Desculpe, apenas usuários VIP podem acessar o Tokyo Box",
    playlistCreated = "Playlist criada com sucesso",
    playlistDeleted = "Playlist excluída com sucesso",
    trackAdded = "Música adicionada à playlist",
    trackRemoved = "Música removida da playlist",
    errorPlayback = "Erro ao reproduzir a música"
}